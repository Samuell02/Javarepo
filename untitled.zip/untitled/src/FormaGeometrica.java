public abstract class FormaGeometrica {

    abstract void CalcularArea();
    abstract void CalcularPerimetro();


}
